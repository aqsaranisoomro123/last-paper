import streamlit as st
import joblib
import re

model = joblib.load("spam_model.pkl")
vectorizer = joblib.load("tfidf.pkl")

st.title("SMS Spam Detector")
st.write("Check whether your message is Spam or Legitimate.")

message = st.text_area("Paste your message here")

if st.button("Analyze Message"):
    if message.strip():

        clean_message = message.lower()
        clean_message = re.sub(
            r"http\S+|www\S+", " URL ", clean_message
        )
        clean_message = re.sub(
            r"[^\w\s]", "", clean_message
        )

        vector = vectorizer.transform([clean_message])
        prediction = model.predict(vector)[0]

        suspicious_words = [
            "urgent", "free prize", "winner",
            "click here", "verify account",
            "password", "otp", "claim now"
        ]

        found = [
            word for word in suspicious_words
            if word in message.lower()
        ]

        if prediction == "spam":
            st.error("Result: SPAM")
            st.write("Risk Level: High")
            st.write("Warning: This message may be unsafe.")
        else:
            st.success("Result: LEGITIMATE")
            st.write("Risk Level: Lower, but stay careful.")

        if found:
            st.subheader("Suspicious Phrases")
            st.write(", ".join(found))
        else:
            st.write("No listed suspicious phrases found.")

        st.subheader("Explanation")
        if prediction == "spam":
            st.write(
                "The model identified this message as spam. "
                "Be careful with unexpected offers and links."
            )
        else:
            st.write(
                "The model identified this message as legitimate. "
                "This does not guarantee the message is safe."
            )

        st.subheader("Safety Recommendations")
        st.write(
            "- Do not open unknown links.\n"
            "- Never share passwords or OTPs.\n"
            "- Verify messages through official channels."
        )

    else:
        st.warning("Please enter a message.")
